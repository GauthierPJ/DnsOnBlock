
const contactAddr = "0xa6f1980ef50d5fd7339c64bdacc92d34e54f1bf6"


const daiAbi = [
    "function get_ip(string memory _dn) public view returns(string memory)",
    "function get_records(address _addr) public view returns(string[] memory)",
    "function set_record(string memory _ipv4, string memory _dn, address _addr) public",
    "function update_ip(string memory _dn, string memory _newip) public"
]



async function get_ip(addr){

    const provider = new ethers.providers.JsonRpcProvider("https://data-seed-prebsc-1-s1.binance.org:8545/");
    contract = new ethers.Contract(contactAddr,daiAbi,provider)

    try{
        res = await contract.get_ip(addr)
        return (res)
    }
    catch(e){
        console.log("Erreur lors de la résolution... :"  + e)
    }
}


browser.webNavigation.onBeforeNavigate.addListener(async (event)=>{
    
    addr = event.url
    chemin = new URL(addr)

    if(chemin.hostname.endsWith('.pfe')){
        
        browser.tabs.update({url:"about:blank"});
        var res = await get_ip(chemin.hostname)
        browser.tabs.update({url:"https://"+res});
        
    }
})

